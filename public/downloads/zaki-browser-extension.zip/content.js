(function() {
	//#region src/commands.ts
	var DEFAULT_DOM_CAP_BYTES = 1e6;
	var CommandError = class extends Error {
		code;
		constructor(code, message) {
			super(message);
			this.code = code;
			this.name = "CommandError";
		}
	};
	function asString(args, key) {
		const v = args[key];
		if (typeof v !== "string") throw new CommandError("invalid_args", `expected string arg "${key}"`);
		return v;
	}
	function asOptionalString(args, key) {
		const v = args[key];
		if (v === void 0 || v === null) return void 0;
		if (typeof v !== "string") throw new CommandError("invalid_args", `expected string-or-missing arg "${key}"`);
		return v;
	}
	function asOptionalNumber(args, key) {
		const v = args[key];
		if (v === void 0 || v === null) return void 0;
		if (typeof v !== "number" || !Number.isFinite(v)) throw new CommandError("invalid_args", `expected number-or-missing arg "${key}"`);
		return v;
	}
	/**
	* Click the first element matching the CSS selector. Throws not_found if no
	* element matches.
	*/
	function cmdClick(doc, args) {
		const selector = asString(args, "selector");
		const el = doc.querySelector(selector);
		if (!el) throw new CommandError("not_found", `no element matches ${selector}`);
		if (!(el instanceof HTMLElement)) throw new CommandError("not_clickable", `element ${selector} is not an HTMLElement`);
		el.click();
		return { clicked: selector };
	}
	/**
	* Is this element a sensitive field we must not write to without explicit
	* server opt-in? (M1) Covers password inputs and credit-card autocomplete
	* tokens (cc-number, cc-csc, cc-exp, ...).
	*/
	function isSensitiveField(el) {
		if (el instanceof HTMLInputElement && el.type.toLowerCase() === "password") return true;
		const ac = el.getAttribute("autocomplete");
		if (ac) {
			for (const token of ac.toLowerCase().split(/\s+/)) if (token.startsWith("cc-")) return true;
		}
		return false;
	}
	/**
	* Type text into an input/textarea. Uses native value setter + dispatched
	* "input" event so frameworks (React, Vue) pick up the change.
	*
	* M1 — default-DENY writes to sensitive fields (password, autocomplete=cc-*)
	* unless `allowSensitive` is true (set from the server-issued
	* Command.allow_sensitive flag). Throws `sensitive_field_blocked` otherwise.
	*/
	function cmdType(doc, args, allowSensitive = false) {
		const selector = asString(args, "selector");
		const text = asString(args, "text");
		const el = doc.querySelector(selector);
		if (!el) throw new CommandError("not_found", `no element matches ${selector}`);
		if (!(el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement)) throw new CommandError("not_typeable", `element ${selector} is not input/textarea`);
		const sensitive = isSensitiveField(el);
		if (sensitive && !allowSensitive) throw new CommandError("sensitive_field_blocked", `refusing to write sensitive field ${selector} without allow_sensitive`);
		const proto = el instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
		const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
		if (setter) setter.call(el, text);
		else el.value = text;
		el.dispatchEvent(new Event("input", { bubbles: true }));
		el.dispatchEvent(new Event("change", { bubbles: true }));
		return {
			typed: text.length,
			sensitive
		};
	}
	/**
	* Fill multiple form fields in one go. Each field is {selector, text}. Stops
	* on the first failing field and reports which one.
	*/
	function cmdFillForm(doc, args, allowSensitive = false) {
		const fields = args["fields"];
		if (!Array.isArray(fields)) throw new CommandError("invalid_args", "fields must be an array");
		let filled = 0;
		let sensitive = false;
		for (let i = 0; i < fields.length; i++) {
			const f = fields[i];
			if (!f || typeof f !== "object") throw new CommandError("invalid_args", `fields[${i}] must be an object`);
			if (cmdType(doc, f, allowSensitive).sensitive) sensitive = true;
			filled++;
		}
		return {
			filled,
			sensitive
		};
	}
	/**
	* innerText of selector (or document.body). Truncated to 100 KB to avoid
	* shipping a megabyte of marketing copy back through the gateway.
	*/
	function cmdGetText(doc, args) {
		const selector = asOptionalString(args, "selector");
		const target = selector ? doc.querySelector(selector) : doc.body;
		if (!target) throw new CommandError("not_found", `no element matches ${selector}`);
		const full = target.innerText ?? "";
		const cap = 1e5;
		if (full.length > cap) return {
			text: full.slice(0, cap),
			truncated: true
		};
		return {
			text: full,
			truncated: false
		};
	}
	/**
	* outerHTML of selector (or document.body). Hard cap at 1MB to avoid runaway
	* payloads; truncated boolean lets the caller know to refine the selector.
	*/
	function cmdGetDom(doc, args) {
		const selector = asOptionalString(args, "selector");
		const target = selector ? doc.querySelector(selector) : doc.body;
		if (!target) throw new CommandError("not_found", `no element matches ${selector}`);
		const html = target.outerHTML ?? "";
		if (html.length > DEFAULT_DOM_CAP_BYTES) return {
			html: html.slice(0, DEFAULT_DOM_CAP_BYTES),
			truncated: true
		};
		return {
			html,
			truncated: false
		};
	}
	/**
	* Wait for an element to appear. Uses MutationObserver + a polling fallback
	* for elements added before the observer attached.
	*
	* state:
	*   "attached"  — element exists in DOM (default)
	*   "visible"   — element exists AND has non-zero bounding box
	*   "detached"  — element does NOT exist
	*/
	async function cmdWaitFor(doc, args) {
		const selector = asString(args, "selector");
		const timeout = asOptionalNumber(args, "timeout_ms") ?? 1e4;
		const state = asOptionalString(args, "state") ?? "attached";
		const startedAt = Date.now();
		const check = () => {
			const el = doc.querySelector(selector);
			if (state === "attached") return el !== null;
			if (state === "detached") return el === null;
			if (state === "visible") {
				if (!el || !(el instanceof HTMLElement)) return false;
				const rect = el.getBoundingClientRect();
				return rect.width > 0 && rect.height > 0;
			}
			return false;
		};
		if (check()) return {
			found: true,
			ms: 0
		};
		return new Promise((resolve) => {
			let observer = null;
			let timer = null;
			const finish = (found) => {
				if (observer) observer.disconnect();
				if (timer) clearTimeout(timer);
				resolve({
					found,
					ms: Date.now() - startedAt
				});
			};
			observer = new MutationObserver(() => {
				if (check()) finish(true);
			});
			observer.observe(doc.documentElement || doc.body, {
				childList: true,
				subtree: true,
				attributes: true
			});
			timer = setTimeout(() => finish(check()), timeout);
		});
	}
	/**
	* Scroll the page. direction is "up" | "down" | "top" | "bottom"; pixels is
	* used for up/down (default 800).
	*/
	function cmdScroll(doc, args) {
		const direction = asString(args, "direction");
		const pixels = asOptionalNumber(args, "pixels") ?? 800;
		const win = doc.defaultView;
		if (!win) throw new CommandError("no_window", "document has no defaultView");
		switch (direction) {
			case "up":
				win.scrollBy({
					top: -pixels,
					behavior: "instant"
				});
				break;
			case "down":
				win.scrollBy({
					top: pixels,
					behavior: "instant"
				});
				break;
			case "top":
				win.scrollTo({
					top: 0,
					behavior: "instant"
				});
				break;
			case "bottom":
				win.scrollTo({
					top: doc.body.scrollHeight,
					behavior: "instant"
				});
				break;
			default: throw new CommandError("invalid_args", `unknown direction ${direction}`);
		}
		return { scrolled: direction };
	}
	var CONTENT_COMMANDS = {
		click: (doc, args) => cmdClick(doc, args),
		type: (doc, args, allow) => cmdType(doc, args, allow),
		fill_form: (doc, args, allow) => cmdFillForm(doc, args, allow),
		get_text: (doc, args) => cmdGetText(doc, args),
		get_dom: (doc, args) => cmdGetDom(doc, args),
		wait_for: (doc, args) => cmdWaitFor(doc, args),
		scroll: (doc, args) => cmdScroll(doc, args)
	};
	/** Tools that must run in the background service worker, not the content script. */
	var BACKGROUND_TOOLS = new Set([
		"navigate",
		"screenshot",
		"list_tabs"
	]);
	/**
	* Validate a command frame before we even attempt dispatch. Used by the
	* background worker so we can reject bad commands with a clean error code
	* without poking the active tab.
	*/
	function validateCommand(c) {
		if (typeof c.command_id !== "string" || c.command_id.length === 0) throw new CommandError("invalid_command", "missing command_id");
		if (typeof c.tool !== "string") throw new CommandError("invalid_command", "missing tool");
		if (!c.args || typeof c.args !== "object") throw new CommandError("invalid_command", "missing args object");
		if (!new Set([...Object.keys(CONTENT_COMMANDS), ...BACKGROUND_TOOLS]).has(c.tool)) throw new CommandError("unknown_tool", `unknown tool ${c.tool}`);
	}
	/**
	* Run a command inside the content script. Throws CommandError on failure;
	* the content script wrapper turns thrown errors into wire-format errors.
	*/
	async function runContentCommand(c, doc) {
		validateCommand(c);
		const fn = CONTENT_COMMANDS[c.tool];
		if (!fn) throw new CommandError("unknown_tool", `tool ${c.tool} is not a content-script command`);
		return await fn(doc, c.args, c.allow_sensitive === true);
	}
	//#endregion
	//#region src/content.ts
	var TOAST_ID = "__nullalis_agent_toast__";
	function ensureToastEl() {
		let el = document.getElementById(TOAST_ID);
		if (el) return el;
		el = document.createElement("div");
		el.id = TOAST_ID;
		Object.assign(el.style, {
			position: "fixed",
			top: "12px",
			right: "12px",
			zIndex: "2147483647",
			padding: "8px 12px",
			background: "rgba(15, 17, 21, 0.92)",
			color: "#f5f5f5",
			font: "12px/1.4 -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
			borderRadius: "6px",
			boxShadow: "0 4px 16px rgba(0,0,0,0.24)",
			pointerEvents: "none",
			maxWidth: "320px",
			opacity: "0",
			transition: "opacity 120ms ease-out"
		});
		document.documentElement.appendChild(el);
		return el;
	}
	var toastHideTimer = null;
	function showToast(message, ttlMs) {
		try {
			const el = ensureToastEl();
			el.textContent = message;
			el.style.opacity = "1";
			if (toastHideTimer) clearTimeout(toastHideTimer);
			if (ttlMs > 0) toastHideTimer = setTimeout(() => {
				el.style.opacity = "0";
			}, ttlMs);
		} catch {}
	}
	function installListener() {
		if (window.__nullalisContentLoaded__) return;
		window.__nullalisContentLoaded__ = true;
		chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
			if (sender.id !== chrome.runtime.id) return false;
			if (msg.type === "show_toast") {
				showToast(msg.message, msg.ttl_ms ?? 2500);
				return false;
			}
			if (msg.type === "execute_in_tab") {
				const cmd = msg.command;
				(async () => {
					try {
						const result = await runContentCommand(cmd, document);
						sendResponse({
							type: "execute_in_tab_result",
							command_id: cmd.command_id,
							ok: true,
							result
						});
					} catch (err) {
						const code = err.code ?? "runtime";
						const message = err instanceof Error ? err.message : String(err);
						sendResponse({
							type: "execute_in_tab_result",
							command_id: cmd.command_id,
							ok: false,
							error: {
								code,
								message
							}
						});
					}
				})();
				return true;
			}
			return false;
		});
	}
	installListener();
	//#endregion
})();
